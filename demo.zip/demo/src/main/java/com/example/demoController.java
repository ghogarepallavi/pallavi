package com.example;

//import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController


public class demoController {
	//private static final String template = "Hello, %s!";
    //private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/greeting")
    public demo greeting(@RequestParam(value="shopName", defaultValue="Null") String shopName,@RequestParam(value="shopAddress", defaultValue="Null") String shopAddress) {
        return new demo(shopName,shopAddress);
}
}